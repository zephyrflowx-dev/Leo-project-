# Leo v5.0 — GitHub Build Package

This package contains the fixed Leo Android source.

Build fixes:
- Valid Android vector icon resource.
- Java and Kotlin JVM targets are both set to Java 17.
- Gradle 8.7 / JDK 17 compatible.

GitHub Actions should extract `leo-source.zip`, build `:app:assembleDebug`, and upload `Leo.apk`.
