# Leo v5.0 — GitHub APK Build

Upload this repository contents to GitHub. The workflow finds `leo-source.zip`, extracts it, builds the Android debug APK, and uploads `Leo.apk` as a GitHub Actions artifact.

UI is kept unchanged; this fix only corrects Kotlin compilation errors in `MainActivity.kt` and the required Compose scroll import.
